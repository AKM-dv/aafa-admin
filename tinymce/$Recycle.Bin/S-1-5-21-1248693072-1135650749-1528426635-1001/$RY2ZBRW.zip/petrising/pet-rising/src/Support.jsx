import { useState } from 'react'
import './Support.css'
import './Home.css'
import SideMenu from './SideMenu'

function Support({ onBack, onShowBooking, onShowMessages, onShowProfile, onShowPetPopup, showPetPopup, selectedPet, setSelectedPet, setShowPetPopup, onLogout, onShowPetInsurance, onShowPetInfo }) {
  const [showSideMenu, setShowSideMenu] = useState(false)

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="logo-icon" />
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="support-body">
          <div className="support-illustration">
            <img src="/support.png" alt="Support" className="support-illustration-img" />
          </div>

          <div className="support-options">
            <div className="support-option-item">
              <svg className="support-option-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M22 6L12 13L2 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="support-option-text">Send an Email</span>
              <svg className="support-option-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="support-option-item">
              <svg className="support-option-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 16.92V19.92C22 20.98 21.1 21.92 20 21.92H4C2.9 21.92 2 20.98 2 19.92V16.92C2 15.86 2.9 14.92 4 14.92H6L8 11.92H16L18 14.92H20C21.1 14.92 22 15.86 22 16.92Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 11.92C13.1046 11.92 14 11.0246 14 9.92C14 8.81543 13.1046 7.92 12 7.92C10.8954 7.92 10 8.81543 10 9.92C10 11.0246 10.8954 11.92 12 11.92Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="support-option-text">Phone</span>
              <svg className="support-option-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="support-option-item">
              <svg className="support-option-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12 11C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9C11.4477 9 11 9.44772 11 10C11 10.5523 11.4477 11 12 11Z" fill="#F55810"/>
              </svg>
              <span className="support-option-text">Whatsapp</span>
              <svg className="support-option-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onBack}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item" onClick={onShowBooking}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item" onClick={onShowMessages}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="black"/>
              <circle cx="12" cy="10" r="1" fill="black"/>
              <circle cx="16" cy="10" r="1" fill="black"/>
            </svg>
            <span className="nav-text">Message</span>
          </div>
          <div className="nav-item" onClick={onShowProfile}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Me</span>
          </div>
        </div>

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
            onShowPetInsurance={onShowPetInsurance}
          />
        )}
      </div>
    </div>
  )
}

export default Support

