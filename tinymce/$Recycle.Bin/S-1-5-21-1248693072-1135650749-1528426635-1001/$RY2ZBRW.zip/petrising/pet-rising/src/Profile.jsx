import { useState, useEffect } from 'react'
import './Profile.css'
import './Home.css'
import SideMenu from './SideMenu'
import Support from './Support'

function Profile({ onShowHome, onShowBooking, onShowMessages, onShowServiceAddress, onShowPetPopup, onLogout, showPetPopup, selectedPet, setSelectedPet, setShowPetPopup, userData, setUserData, onShowPetInsurance, onShowPetInfo }) {
  const [isEditing, setIsEditing] = useState(false)
  const [editName, setEditName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editErrors, setEditErrors] = useState({})
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [showSupport, setShowSupport] = useState(false)
  
  const getStoredUserData = () => {
    try {
      const saved = localStorage.getItem('userData')
      return saved ? JSON.parse(saved) : null
    } catch {
      return null
    }
  }
  
  const displayUserData = userData && (userData.name || userData.email) ? userData : getStoredUserData() || { name: '', email: '' }

  if (showSupport) {
    return (
      <Support 
        onBack={() => setShowSupport(false)}
        onShowBooking={() => {
          setShowSupport(false)
          onShowBooking()
        }}
        onShowMessages={() => {
          setShowSupport(false)
          onShowMessages()
        }}
        onShowProfile={() => {
          setShowSupport(false)
        }}
        onShowPetPopup={onShowPetPopup}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
      />
    )
  }

  useEffect(() => {
    const stored = getStoredUserData()
    if (stored) {
      setEditName(stored.name || '')
      setEditEmail(stored.email || '')
    } else if (userData) {
      setEditName(userData.name || '')
      setEditEmail(userData.email || '')
    }
  }, [userData])


  const handleEdit = () => {
    setIsEditing(true)
    setEditName(displayUserData?.name || '')
    setEditEmail(displayUserData?.email || '')
  }

  const handleSave = () => {
    const newErrors = {}
    
    if (!editName.trim()) {
      newErrors.name = 'Name is required'
    }
    if (!editEmail.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editEmail)) {
      newErrors.email = 'Please enter a valid email address'
    }

    if (Object.keys(newErrors).length > 0) {
      setEditErrors(newErrors)
      return
    }

    const updatedData = { name: editName.trim(), email: editEmail.trim() }
    setUserData(updatedData)
    localStorage.setItem('userData', JSON.stringify(updatedData))
    setIsEditing(false)
    setEditErrors({})
  }

  const handleCancel = () => {
    setIsEditing(false)
    setEditName(displayUserData?.name || '')
    setEditEmail(displayUserData?.email || '')
    setEditErrors({})
  }

  const openPetSelection = () => {
    if (onShowPetPopup) {
      onShowPetPopup()
    } else if (setShowPetPopup) {
      setShowPetPopup(true)
    }
  }

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="logo-icon" />
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="profile-body">
          <div className="profile-card">
            <div className="profile-icon-large">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
                <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
                <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="profile-info">
              {isEditing ? (
                <div className="profile-edit-form">
                  <input
                    type="text"
                    className={`profile-edit-input ${editErrors.name ? 'error' : ''}`}
                    value={editName}
                    onChange={(e) => {
                      setEditName(e.target.value)
                      if (editErrors.name) {
                        setEditErrors({ ...editErrors, name: '' })
                      }
                    }}
                    placeholder="Enter your name"
                  />
                  {editErrors.name && <p className="profile-edit-error">{editErrors.name}</p>}
                  <input
                    type="email"
                    className={`profile-edit-input ${editErrors.email ? 'error' : ''}`}
                    value={editEmail}
                    onChange={(e) => {
                      setEditEmail(e.target.value)
                      if (editErrors.email) {
                        setEditErrors({ ...editErrors, email: '' })
                      }
                    }}
                    placeholder="Enter your email"
                  />
                  {editErrors.email && <p className="profile-edit-error">{editErrors.email}</p>}
                  <div className="profile-edit-actions">
                    <button className="profile-save-btn" onClick={handleSave}>Save</button>
                    <button className="profile-cancel-btn" onClick={handleCancel}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <h3 className="profile-name">{displayUserData?.name || ''}</h3>
                  <p className="profile-email">{displayUserData?.email || ''}</p>
                </>
              )}
            </div>
            {!isEditing && (
              <button className="profile-edit-btn" onClick={handleEdit}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M11 4H4C3.46957 4 2.96086 4.21071 2.58579 4.58579C2.21071 4.96086 2 5.46957 2 6V20C2 20.5304 2.21071 21.0391 2.58579 21.4142C2.96086 21.7893 3.46957 22 4 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V13" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M18.5 2.50023C18.8978 2.10243 19.4374 1.87891 20 1.87891C20.5626 1.87891 21.1022 2.10243 21.5 2.50023C21.8978 2.89804 22.1213 3.43762 22.1213 4.00023C22.1213 4.56284 21.8978 5.10243 21.5 5.50023L12 15.0002L8 16.0002L9 12.0002L18.5 2.50023Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            )}
          </div>

          <div className="profile-section">
            <div className="profile-section-header">
              <h4 className="profile-section-title">Your Pets:</h4>
              <button className="add-pet-btn" onClick={openPetSelection}>
                <div className="add-pet-icon">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8" cy="8" r="7" fill="#F55810"/>
                    <path d="M8 4V12M4 8H12" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </div>
                <span className="add-pet-text">Add Pet</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </div>

          <div className="profile-menu-list">
            <div className="profile-menu-item" onClick={onShowServiceAddress}>
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 10C21 17 12 23 12 23C12 23 3 17 3 10C3 7.61305 3.94821 5.32387 5.63604 3.63604C7.32387 1.94821 9.61305 1 12 1C14.3869 1 16.6761 1.94821 18.364 3.63604C20.0518 5.32387 21 7.61305 21 10Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="10" r="3" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="profile-menu-text">Service Address</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="profile-menu-item" onClick={onShowMessages}>
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="8" cy="10" r="1" fill="#F55810"/>
                <circle cx="12" cy="10" r="1" fill="#F55810"/>
                <circle cx="16" cy="10" r="1" fill="#F55810"/>
              </svg>
              <span className="profile-menu-text">Messages</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="profile-menu-item" onClick={onShowBooking}>
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="profile-menu-text">Booking</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="profile-menu-item">
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.59 13.41L13 20.99C12.7 21.3 12.35 21.57 11.97 21.79C11.59 22.01 11.18 22.17 10.76 22.27C10.34 22.37 9.9 22.41 9.46 22.38C9.02 22.35 8.59 22.25 8.19 22.08C7.79 21.91 7.42 21.68 7.1 21.39C6.78 21.1 6.51 20.75 6.29 20.37C6.07 19.99 5.91 19.58 5.81 19.16C5.71 18.74 5.67 18.3 5.7 17.86C5.73 17.42 5.83 16.99 6 16.59L13 9C13.26 8.74 13.51 8.5 13.75 8.28C14 8.06 14.23 7.85 14.45 7.65C14.67 7.45 14.88 7.26 15.08 7.08C15.28 6.9 15.47 6.73 15.65 6.57C15.83 6.41 16 6.26 16.16 6.12C16.32 5.98 16.47 5.85 16.61 5.73L20.59 1.75C20.79 1.55 21.04 1.45 21.32 1.45C21.6 1.45 21.85 1.55 22.05 1.75C22.25 1.95 22.35 2.2 22.35 2.48C22.35 2.76 22.25 3.01 22.05 3.21L18.07 7.19C17.93 7.33 17.8 7.48 17.68 7.64C17.56 7.8 17.45 7.97 17.35 8.15C17.25 8.33 17.16 8.52 17.08 8.72C17 8.92 16.93 9.13 16.88 9.35C16.83 9.57 16.79 9.8 16.77 10.04C16.75 10.28 16.75 10.52 16.77 10.76C16.79 11 16.83 11.23 16.88 11.45C16.93 11.67 17 11.88 17.08 12.08C17.16 12.28 17.25 12.47 17.35 12.65C17.45 12.83 17.56 13 17.68 13.16C17.8 13.32 17.93 13.47 18.07 13.61L22.05 17.59C22.25 17.79 22.35 18.04 22.35 18.32C22.35 18.6 22.25 18.85 22.05 19.05C21.85 19.25 21.6 19.35 21.32 19.35C21.04 19.35 20.79 19.25 20.59 19.05L20.59 13.41Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="profile-menu-text">Coupons</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>

          <div className="profile-menu-list">
            <div className="profile-menu-item" onClick={onLogout}>
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M16 17L21 12L16 7" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M21 12H9" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="profile-menu-text">Logout</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <div className="profile-menu-item">
              <svg className="profile-menu-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 6H5H21" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6H19Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="profile-menu-text">Delete Account</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 18L15 12L9 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>

          <div className="profile-version">
            <p className="profile-version-text">Version 8.3.2</p>
          </div>
        </div>

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onShowHome}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item" onClick={onShowBooking}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item" onClick={onShowMessages}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="black"/>
              <circle cx="12" cy="10" r="1" fill="black"/>
              <circle cx="16" cy="10" r="1" fill="black"/>
            </svg>
            <span className="nav-text">Message</span>
          </div>
          <div className="nav-item active">
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text active">Me</span>
          </div>
        </div>

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
            onShowSupport={() => {
              setShowSideMenu(false)
              setShowSupport(true)
            }}
            onShowPetInsurance={onShowPetInsurance}
          />
        )}
      </div>
    </div>
  )
}

export default Profile

