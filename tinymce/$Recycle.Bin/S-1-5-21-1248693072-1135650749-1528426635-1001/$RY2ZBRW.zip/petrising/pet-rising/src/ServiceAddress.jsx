import { useState } from 'react'
import './ServiceAddress.css'
import './Home.css'
import SideMenu from './SideMenu'
import Support from './Support'

function ServiceAddress({ onBack, onShowBooking, onShowMessages, onShowProfile, onShowPetPopup, showPetPopup, selectedPet, setSelectedPet, setShowPetPopup, onLogout, onShowPetInsurance, onShowPetInfo }) {
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [showSupport, setShowSupport] = useState(false)
  const [addresses, setAddresses] = useState([])
  const [showAddressForm, setShowAddressForm] = useState(false)
  const [editingAddressId, setEditingAddressId] = useState(null)
  const [formError, setFormError] = useState('')
  const [formData, setFormData] = useState({
    contactName: '',
    phone: '',
    addressLine: '',
    landmark: '',
    city: '',
    state: '',
    pincode: '',
    instructions: ''
  })

  const resetForm = () => {
    setFormData({
      contactName: '',
      phone: '',
      addressLine: '',
      landmark: '',
      city: '',
      state: '',
      pincode: '',
      instructions: ''
    })
    setFormError('')
    setEditingAddressId(null)
  }

  const handleInputChange = (event) => {
    const { name, value } = event.target
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }))
  }

  const handleFormSubmit = (event) => {
    event.preventDefault()
    const requiredFields = ['contactName', 'phone', 'addressLine', 'landmark', 'city', 'state', 'pincode']
    const hasEmptyRequiredField = requiredFields.some((field) => !formData[field].trim())

    if (hasEmptyRequiredField) {
      setFormError('Please fill all required details before saving the address.')
      return
    }

    if (editingAddressId) {
      setAddresses((prev) =>
        prev.map((item) =>
          item.id === editingAddressId
            ? {
                ...item,
                ...formData
              }
            : item
        )
      )
    } else {
      setAddresses((prev) => [
        ...prev,
        {
          id: Date.now(),
          ...formData
        }
      ])
    }

    resetForm()
    setShowAddressForm(false)
  }

  const openAddressForm = (address = null) => {
    if (address) {
      setFormData({
        contactName: address.contactName || '',
        phone: address.phone || '',
        addressLine: address.addressLine || '',
        landmark: address.landmark || '',
        city: address.city || '',
        state: address.state || '',
        pincode: address.pincode || '',
        instructions: address.instructions || ''
      })
      setEditingAddressId(address.id)
      setFormError('')
    } else {
      resetForm()
    }
    setShowAddressForm(true)
  }

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  if (showSupport) {
    return (
      <Support 
        onBack={() => setShowSupport(false)}
        onShowBooking={() => {
          setShowSupport(false)
          onShowBooking()
        }}
        onShowMessages={() => {
          setShowSupport(false)
          onShowMessages()
        }}
        onShowProfile={() => {
          setShowSupport(false)
          onShowProfile()
        }}
        onShowPetPopup={onShowPetPopup}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
      />
    )
  }

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <h2 className="service-address-title">Service Address</h2>
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className={`service-address-body ${addresses.length === 0 ? 'empty' : ''}`}>
          {addresses.length === 0 ? (
            <div className="service-address-empty-state">
              <img src="/Booking_illustration.png" alt="Service Address" className="service-address-illustration" />
              <h3 className="service-address-empty-title">No Addresses Added</h3>
            </div>
          ) : (
            <div className="service-address-list">
              {addresses.map((address) => (
                <div className="address-card" key={address.id}>
                  <div className="address-card-header">
                    <div>
                      <h4 className="address-contact-name">{address.contactName}</h4>
                      <p className="address-phone">{address.phone}</p>
                    </div>
                    <span className="address-pincode">{address.pincode}</span>
                    <button
                      className="address-edit-button"
                      aria-label="Edit address"
                      onClick={() => openAddressForm(address)}
                    >
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M12 20H21"
                          stroke="#F55810"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M16.5 3.5C16.8978 3.10218 17.4374 2.87868 18 2.87868C18.2786 2.87868 18.5544 2.93342 18.8118 3.03961C19.0693 3.1458 19.303 3.30129 19.5 3.5C19.6978 3.89782 19.9213 4.43738 19.9213 5C19.9213 5.27864 19.8666 5.5544 19.7604 5.81183C19.6542 6.06927 19.4987 6.303 19.3 6.5L7 18.8L3 20L4.2 16L16.5 3.5Z"
                          stroke="#F55810"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </button>
                  </div>
                  <div className="address-body">
                    <p className="address-line">{address.addressLine}</p>
                    <p className="address-meta">
                      {address.landmark && <span>{address.landmark}</span>}
                      {address.city && address.state && (
                        <span>
                          {address.city}, {address.state}
                        </span>
                      )}
                    </p>
                    {address.instructions && (
                      <p className="address-instructions">Instructions: {address.instructions}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onBack}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item" onClick={onShowBooking}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item" onClick={onShowMessages}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="black"/>
              <circle cx="12" cy="10" r="1" fill="black"/>
              <circle cx="16" cy="10" r="1" fill="black"/>
            </svg>
            <span className="nav-text">Message</span>
          </div>
          <div className="nav-item" onClick={onShowProfile}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Me</span>
          </div>
        </div>

        <button type="button" className="add-address-button" onClick={() => openAddressForm()}>
          <svg className="add-address-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M9 22V12H15V22" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="add-address-text">Add Address</span>
        </button>

        {showAddressForm && (
          <div
            className="address-form-overlay"
            onClick={() => {
              setShowAddressForm(false)
              resetForm()
            }}
          >
            <div className="address-form-container" onClick={(e) => e.stopPropagation()}>
              <h3 className="address-form-title">
                {editingAddressId ? 'Edit Service Address' : 'Add Service Address'}
              </h3>
              {formError && <p className="address-form-error">{formError}</p>}
              <form className="address-form" onSubmit={handleFormSubmit}>
                <div className="form-row">
                  <label className="form-label" htmlFor="contactName">Contact Name</label>
                  <input
                    id="contactName"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleInputChange}
                    className="form-input"
                    placeholder="Full name"
                  />
                </div>
                <div className="form-row">
                  <label className="form-label" htmlFor="phone">Phone Number</label>
                  <input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="form-input"
                    placeholder="10-digit mobile number"
                  />
                </div>
                <div className="form-row">
                  <label className="form-label" htmlFor="addressLine">Address</label>
                  <textarea
                    id="addressLine"
                    name="addressLine"
                    value={formData.addressLine}
                    onChange={handleInputChange}
                    className="form-textarea"
                    rows="3"
                    placeholder="House number, street, area"
                  />
                </div>
                <div className="form-row">
                  <label className="form-label" htmlFor="landmark">Landmark</label>
                  <input
                    id="landmark"
                    name="landmark"
                    value={formData.landmark}
                    onChange={handleInputChange}
                    className="form-input"
                    placeholder="Nearby landmark"
                  />
                </div>
                <div className="form-grid">
                  <div className="form-row">
                    <label className="form-label" htmlFor="city">City</label>
                    <input
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="form-input"
                      placeholder="City"
                    />
                  </div>
                  <div className="form-row">
                    <label className="form-label" htmlFor="state">State</label>
                    <input
                      id="state"
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      className="form-input"
                      placeholder="State"
                    />
                  </div>
                  <div className="form-row">
                    <label className="form-label" htmlFor="pincode">Pincode</label>
                    <input
                      id="pincode"
                      name="pincode"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      className="form-input"
                      placeholder="Pincode"
                    />
                  </div>
                </div>
                <div className="form-row">
                  <label className="form-label" htmlFor="instructions">Additional Instructions</label>
                  <textarea
                    id="instructions"
                    name="instructions"
                    value={formData.instructions}
                    onChange={handleInputChange}
                    className="form-textarea"
                    rows="2"
                    placeholder="Any extra details for our team"
                  />
                </div>
                <div className="form-actions">
                  <button
                    type="button"
                    className="form-button form-button--secondary"
                    onClick={() => {
                      setShowAddressForm(false)
                      resetForm()
                    }}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="form-button form-button--primary">
                    {editingAddressId ? 'Update Address' : 'Save Address'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
            onShowSupport={() => {
              setShowSideMenu(false)
              setShowSupport(true)
            }}
            onShowPetInsurance={onShowPetInsurance}
          />
        )}
      </div>
    </div>
  )
}

export default ServiceAddress

