import { useEffect, useState } from 'react'
import './Booking.css'
import './Home.css'
import SideMenu from './SideMenu'
import Support from './Support'

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  pincode: '',
  city: '',
  state: '',
  country: '',
  service: '',
  schedule: ''
}

const providerOptions = [
  {
    name: 'Aryan',
    role: 'Medical Consultant',
    price: '2000',
    rating: '4.8 Ratings',
    ratingStars: 4.5,
    avatar: '/hero1.png'
  },
  {
    name: 'Meet',
    role: 'Medical Consultant',
    price: '1600',
    rating: '3.9 Ratings',
    ratingStars: 3.9,
    avatar: '/hero2.png'
  },
  {
    name: 'Anshi',
    role: 'Medical Consultant',
    price: '1500',
    rating: '3.5 Ratings',
    ratingStars: 3.5,
    avatar: '/hero3.png'
  }
]

const formatInr = (value) =>
  typeof value === 'number'
    ? new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(value)
    : value

const serviceCatalogData = {
  dogTraining: {
    title: 'Dog Training',
    searchPlaceholder: 'Search dog training packages',
    services: [
      {
        id: 'dog-advanced-guard',
        name: 'Advanced Training (Guard)',
        description: 'Intensive guard obedience training tailored for protection.',
        price: 43999,
        image: '/service_category.png'
      },
      {
        id: 'dog-aggression-control',
        name: 'Aggression Behaviour Control Training',
        description: 'Focus sessions to manage reactivity, anxiety and aggression triggers.',
        price: 35999,
        image: '/service_category.png'
      },
      {
        id: 'dog-basic',
        name: 'Basic Training',
        description: 'Foundational on-leash obedience and manners training for all dogs.',
        price: 15999,
        image: '/service_category.png'
      },
      {
        id: 'dog-behaviour',
        name: 'Behaviour Training',
        description: 'Improve everyday behaviour, recall and social confidence.',
        price: 21999,
        image: '/service_category.png'
      },
      {
        id: 'dog-puppy',
        name: 'Puppy Manners Bootcamp',
        description: '4-week crate, potty and impulse control training for pups.',
        price: 8999,
        image: '/service_category.png'
      }
    ]
  },
  catTraining: {
    title: 'Cat Training',
    searchPlaceholder: 'Search cat training plans',
    services: [
      {
        id: 'cat-litter-reset',
        name: 'Litter Box Reset Program',
        description: 'Resolve litter issues with behaviour reset and enrichment.',
        price: 12999,
        image: '/service_category.png'
      },
      {
        id: 'cat-behaviour',
        name: 'Behaviour Balance Training',
        description: 'Custom sessions for aggression, anxiety and scratching habits.',
        price: 17999,
        image: '/service_category.png'
      },
      {
        id: 'cat-clicker',
        name: 'Clicker Obedience Basics',
        description: 'Teach fun tricks and recall using positive reinforcement.',
        price: 9999,
        image: '/service_category.png'
      }
    ]
  },
  petGrooming: {
    title: 'Pet Grooming',
    searchPlaceholder: 'Search grooming services',
    services: [
      {
        id: 'grooming-deluxe',
        name: 'Deluxe Spa Groom',
        description: 'Bath, blow dry, haircut, nail trim and spa finish.',
        price: 3499,
        image: '/service_category.png'
      },
      {
        id: 'grooming-bath',
        name: 'Quick Bath & Brush',
        description: 'Perfect for in-between maintenance with coat conditioning.',
        price: 1499,
        image: '/service_category.png'
      },
      {
        id: 'grooming-premium',
        name: 'Premium Styling Session',
        description: 'Breed-specific styling with de-shedding and paw spa.',
        price: 4999,
        image: '/service_category.png'
      }
    ]
  },
  vetOnCall: {
    title: 'Vet On Call',
    searchPlaceholder: 'Search vet consultation plans',
    services: [
      {
        id: 'vet-general',
        name: 'General Consultation (30 mins)',
        description: 'Video consult covering basic health checks and advice.',
        price: 899,
        image: '/service_category.png'
      },
      {
        id: 'vet-followup',
        name: 'Follow-up Consultation',
        description: 'Follow-up with the same vet for treatment continuity.',
        price: 699,
        image: '/service_category.png'
      },
      {
        id: 'vet-emergency',
        name: 'Emergency Vet Call',
        description: 'Immediate triage and guidance for urgent situations.',
        price: 1499,
        image: '/service_category.png'
      }
    ]
  },
  dogWalking: {
    title: 'Dog Walking',
    searchPlaceholder: 'Search dog walking packages',
    services: [
      {
        id: 'walk-daily',
        name: 'Daily Walk (30 mins)',
        description: 'Everyday exercise with GPS tracking and hydration breaks.',
        price: 2999,
        image: '/service_category.png'
      },
      {
        id: 'walk-premium',
        name: 'Premium Walk & Play',
        description: '60-minute walk with playtime, enrichment and photo updates.',
        price: 4599,
        image: '/service_category.png'
      },
      {
        id: 'walk-weekend',
        name: 'Weekend Adventure',
        description: 'Nature trail walk with pickup and drop for your pet.',
        price: 5599,
        image: '/service_category.png'
      }
    ]
  },
  petBoarding: {
    title: 'Pet Boarding',
    searchPlaceholder: 'Search boarding stays',
    services: [
      {
        id: 'boarding-premium',
        name: 'Premium Home Boarding',
        description: 'Stay with verified pet host, daily walks and photo updates.',
        price: 2499,
        image: '/service_category.png'
      },
      {
        id: 'boarding-luxury',
        name: 'Luxury Suite Stay',
        description: 'Suite stay with CCTV access, play area, and grooming add-ons.',
        price: 3899,
        image: '/service_category.png'
      },
      {
        id: 'boarding-daycare',
        name: 'Day Care Pass',
        description: 'Daytime socialisation with trained handlers and enrichment.',
        price: 1499,
        image: '/service_category.png'
      }
    ]
  }
}

function Booking({
  mode = 'dashboard',
  onModeChange,
  bookings = [],
  setBookings,
  selectedServiceCategory,
  setSelectedServiceCategory,
  preselectedServiceName = '',
  setPreselectedServiceName,
  onShowHome,
  onShowMessages,
  onShowProfile,
  onShowPetPopup,
  showPetPopup,
  selectedPet,
  setSelectedPet,
  setShowPetPopup,
  onLogout,
  onShowPetInsurance,
  onShowPetInfo
}) {
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [showSupport, setShowSupport] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState(providerOptions[0])
  const [selectedPayment, setSelectedPayment] = useState('pay-now')
  const [showConfirmationModal, setShowConfirmationModal] = useState(false)
  const [activeBookingsTab, setActiveBookingsTab] = useState('ongoing')
  const [expandedBookingId, setExpandedBookingId] = useState(null)
  const [serviceSearch, setServiceSearch] = useState('')
  const [expandedTrackingBooking, setExpandedTrackingBooking] = useState(null)

  const ongoingList = (bookings || []).filter((booking) => booking.status !== 'history')
  const historyList = (bookings || []).filter((booking) => booking.status === 'history')

  const selectedCatalog =
    (selectedServiceCategory && serviceCatalogData[selectedServiceCategory]) || null
  const filteredCatalogServices = selectedCatalog
    ? selectedCatalog.services.filter((service) =>
        service.name.toLowerCase().includes(serviceSearch.trim().toLowerCase())
      )
    : []

  useEffect(() => {
    if (mode !== 'serviceCatalog') {
      setServiceSearch('')
    }
  }, [mode])

  useEffect(() => {
    if (preselectedServiceName) {
      setFormData((prev) => ({
        ...prev,
        service: preselectedServiceName
      }))
    }
  }, [preselectedServiceName])
  const [formData, setFormData] = useState(initialFormState)
  const [scheduleInputType, setScheduleInputType] = useState('text')
  const [pincodeStatus, setPincodeStatus] = useState({ loading: false, error: '' })

  const handleChange = (event) => {
    const { name, value } = event.target

    if (name === 'pincode') {
      const sanitized = value.replace(/\D/g, '').slice(0, 6)
      setFormData((prev) => ({ ...prev, [name]: sanitized }))
      return
    }

    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    if (onModeChange) {
      onModeChange('providers')
    }
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  useEffect(() => {
    const pin = formData.pincode.trim()

    if (pin.length === 6) {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 1500)

      setPincodeStatus({ loading: true, error: '' })

      fetch(`https://api.postalpincode.in/pincode/${pin}`, { signal: controller.signal })
        .then((response) => response.json())
        .then((data) => {
          const result = data?.[0]
          if (result && result.Status === 'Success' && result.PostOffice?.length) {
            const info = result.PostOffice[0]
            setFormData((prev) => ({
              ...prev,
              city: info.District || info.Name || prev.city,
              state: info.State || prev.state,
              country: info.Country || prev.country
            }))
            setPincodeStatus({ loading: false, error: '' })
          } else {
            setPincodeStatus({ loading: false, error: 'Pincode not found. Please verify.' })
            setFormData((prev) => ({ ...prev, state: '', country: '' }))
          }
        })
        .catch((error) => {
          if (error.name !== 'AbortError') {
            setPincodeStatus({ loading: false, error: 'Unable to fetch location. Try again.' })
            setFormData((prev) => ({ ...prev, state: '', country: '' }))
          }
        })
        .finally(() => {
          clearTimeout(timeoutId)
        })

      return () => {
        clearTimeout(timeoutId)
        controller.abort()
      }
    } else {
      setPincodeStatus({ loading: false, error: '' })
      setFormData((prev) => ({ ...prev, state: '', country: '' }))
    }
  }, [formData.pincode])

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  if (showSupport) {
    return (
      <Support 
        onBack={() => setShowSupport(false)}
        onShowBooking={() => {
          setShowSupport(false)
          if (onModeChange) {
            onModeChange('dashboard')
          }
        }}
        onShowMessages={() => {
          setShowSupport(false)
          onShowMessages()
        }}
        onShowProfile={() => {
          setShowSupport(false)
          onShowProfile()
        }}
        onShowPetPopup={onShowPetPopup}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
      />
    )
  }

  return (
    <div className="home-container booking-container">
      <div className="home-content">
        <header className="booking-header">
          <button className="booking-header-icon" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="#1c1c1c" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="#1c1c1c" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="#1c1c1c" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="booking-header-brand">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="booking-brand-logo" />
          </div>
          <button className="booking-header-icon" onClick={onShowHome}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="#1c1c1c" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="#1c1c1c" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="#1c1c1c" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        {mode === 'form' ? (
          <div className="booking-form-container">
            <div className="booking-form-header">
              <div>
                <h1 className="booking-title">Book Your Pet</h1>
                <p className="booking-subtitle">Tell us a few details and we’ll schedule the service.</p>
              </div>
              <div className="booking-mascot">
                <img src="/Booking_illustration.png" alt="Pet mascot" />
              </div>
            </div>

            <form className="booking-form-card" onSubmit={handleSubmit}>
              <div className="booking-form-grid">
                <div className="booking-field">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Full Name"
                    required
                  />
                </div>
                <div className="booking-field">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email Address"
                    required
                  />
                </div>
                <div className="booking-field">
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="Contact Number"
                    required
                  />
                </div>
                <div className="booking-field">
                  <input
                    type="text"
                    name="pincode"
                    value={formData.pincode}
                    onChange={handleChange}
                    placeholder="Pincode"
                    required
                  />
                  {pincodeStatus.error && (
                    <p className="booking-helper-text booking-helper-text--error">{pincodeStatus.error}</p>
                  )}
                </div>
                <div className="booking-field">
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    placeholder="City"
                    required
                  />
                </div>
                <div className="booking-field">
                  <input
                    type="text"
                    name="state"
                    value={formData.state}
                    onChange={handleChange}
                    placeholder="State"
                    required
                  />
                </div>
                <div className="booking-field">
                  <input
                    type="text"
                    name="country"
                    value={formData.country}
                    onChange={handleChange}
                    placeholder="Country"
                    required
                  />
                </div>
                <div className="booking-field booking-field--select">
                  <select
                    name="service"
                    value={formData.service}
                    onChange={(event) => {
                      handleChange(event)
                      if (setPreselectedServiceName) {
                        setPreselectedServiceName(event.target.value)
                      }
                    }}
                    required
                  >
                    <option value="">Service</option>
                    {['Dog Training', 'Cat Training', 'Pet Grooming', 'Vet on Call', 'Dog Walking', 'Pet Boarding']
                      .concat(
                        preselectedServiceName &&
                          ![
                            'Dog Training',
                            'Cat Training',
                            'Pet Grooming',
                            'Vet on Call',
                            'Dog Walking',
                            'Pet Boarding'
                          ].includes(preselectedServiceName)
                          ? [preselectedServiceName]
                          : []
                      )
                      .filter((option, index, self) => option && self.indexOf(option) === index)
                      .map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                  </select>
                  <span className="booking-select-icon" aria-hidden="true">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6 9L12 15L18 9" stroke="#1c1c1c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </span>
                </div>
                <div className="booking-field booking-field--schedule">
                  <div className={`booking-field-with-icon ${formData.schedule ? 'has-value' : ''}`}>
                    {!formData.schedule && (
                      <span className="booking-placeholder">Preferred Date &amp; Time</span>
                    )}
                    <input
                      type={scheduleInputType}
                      name="schedule"
                      value={formData.schedule}
                      onChange={handleChange}
                      required
                      onFocus={() => setScheduleInputType('datetime-local')}
                      onBlur={(event) => {
                        if (!event.target.value) {
                          setScheduleInputType('text')
                        }
                      }}
                    />
                    <span className="booking-field-icon" aria-hidden="true">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="3" y="4" width="18" height="18" rx="2" stroke="#1c1c1c" strokeWidth="1.5"/>
                        <path d="M16 2V6" stroke="#1c1c1c" strokeWidth="1.5" strokeLinecap="round"/>
                        <path d="M8 2V6" stroke="#1c1c1c" strokeWidth="1.5" strokeLinecap="round"/>
                        <path d="M3 10H21" stroke="#1c1c1c" strokeWidth="1.5" strokeLinecap="round"/>
                        <circle cx="12" cy="15" r="1" fill="#1c1c1c"/>
                      </svg>
                    </span>
                  </div>
                </div>
              </div>

              <button type="submit" className="booking-submit-button">
                Book Now
              </button>
            </form>
          </div>
        ) : mode === 'serviceCatalog' ? (
          <div className="service-catalog-container">
            <header className="service-catalog-header">
              <button
                className="service-catalog-back"
                onClick={() => {
                  if (typeof setSelectedServiceCategory === 'function') {
                    setSelectedServiceCategory(null)
                  }
                  setServiceSearch('')
                  if (onModeChange) {
                    onModeChange('dashboard')
                  }
                  if (onShowHome) {
                    onShowHome()
                  }
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15 18L9 12L15 6" stroke="#ff6219" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <h2>{selectedCatalog?.title || 'Services'}</h2>
              <div className="service-catalog-placeholder"></div>
            </header>

            <div className="service-catalog-search">
              <div className="service-search-input">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M21 21L16.65 16.65M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 6.58172 3 11 3C15.4183 3 19 6.58172 19 11Z" stroke="#7f7f7f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <input
                  type="text"
                  value={serviceSearch}
                  placeholder={selectedCatalog?.searchPlaceholder || 'Search services'}
                  onChange={(event) => setServiceSearch(event.target.value)}
                />
              </div>
              <button className="service-search-add">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5V19M5 12H19" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>

            <div className="service-catalog-list">
              {filteredCatalogServices.length ? (
                filteredCatalogServices.map((service) => (
                  <div key={service.id} className="service-catalog-card">
                    <div className="service-catalog-image">
                      <img src={service.image} alt={service.name} />
                    </div>
                    <div className="service-catalog-info">
                      <div className="service-catalog-price">{formatInr(service.price)}</div>
                      <div className="service-catalog-title-text">{service.name}</div>
                      <p className="service-catalog-description">{service.description}</p>
                      <button
                        className="service-catalog-book-btn"
                        onClick={() => {
                          if (setPreselectedServiceName) {
                            setPreselectedServiceName(service.name)
                          }
                          setFormData((prev) => ({
                            ...prev,
                            service: service.name
                          }))
                          if (typeof setSelectedServiceCategory === 'function') {
                            setSelectedServiceCategory(null)
                          }
                          if (onModeChange) {
                            onModeChange('form')
                          }
                          window.scrollTo({ top: 0, behavior: 'smooth' })
                        }}
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="service-catalog-empty">
                  <p>No services found. Try a different search.</p>
                </div>
              )}
            </div>
          </div>
        ) : mode === 'providers' ? (
          <div className="provider-list-container">
            <div className="provider-header">
              <button
                className="provider-back-button"
                onClick={() => {
                  if (onModeChange) {
                    onModeChange('form')
                  }
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15 18L9 12L15 6" stroke="#ff6219" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <h2>Choose A Service Provider</h2>
            </div>
            <div className="provider-cards">
              {providerOptions.map((provider) => (
                <div key={provider.name} className="provider-card">
                  <div className="provider-avatar">
                    <img src={provider.avatar} alt={provider.name} />
                  </div>
                  <div className="provider-info">
                    <h3>{provider.name}</h3>
                    <p className="provider-role">{provider.role}</p>
                    <div className="provider-meta">
                      <span className="provider-price">
                        <span className="provider-price-value">₹ {provider.price}</span>
                      </span>
                      <span className="provider-rating">
                        <svg className="provider-rating-icon" width="16" height="16" viewBox="0 0 24 24" fill="#ffaa3b" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 3L14.4721 8.00062L20 8.94523L16 12.8925L16.9443 18.4L12 15.9279L7.05573 18.4L8 12.8925L4 8.94523L9.52786 8.00062L12 3Z"/>
                        </svg>
                        <span className="provider-rating-value">{provider.rating}</span>
                      </span>
                    </div>
                  </div>
                  <button
                    className="provider-action"
                    onClick={() => {
                      setSelectedProvider(provider)
                      if (onModeChange) {
                        onModeChange('confirmation')
                      }
                    }}
                  >
                    Book Now
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : mode === 'confirmation' ? (
          <div className="provider-confirmation-container">
            <div className="provider-highlight-card">
              <div className="provider-highlight-avatar">
                <img src={selectedProvider.avatar} alt={selectedProvider.name} />
              </div>
              <div className="provider-highlight-info">
                <div className="provider-highlight-header">
                  <h2>{selectedProvider.name}</h2>
                  <div className="provider-highlight-price">₹ {selectedProvider.price}</div>
                </div>
                <p className="provider-highlight-role">{selectedProvider.role}</p>
                <div className="provider-highlight-rating">
                  <div className="provider-highlight-stars">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span
                        key={star}
                        className={star <= Math.round(selectedProvider.ratingStars) ? 'filled' : ''}
                      >
                        ★
                      </span>
                    ))}
                  </div>
                  <span className="provider-highlight-rating-text">{selectedProvider.rating}</span>
                </div>
              </div>
            </div>

            <div className="payment-section">
              <h3>Payment</h3>
              <div className="payment-options">
                <label className={`payment-option ${selectedPayment === 'pay-now' ? 'selected' : ''}`}>
                  <input
                    type="radio"
                    name="payment"
                    value="pay-now"
                    checked={selectedPayment === 'pay-now'}
                    onChange={(event) => setSelectedPayment(event.target.value)}
                  />
                  <span>Pay Now</span>
                </label>
                <label className={`payment-option ${selectedPayment === 'pay-later' ? 'selected' : ''}`}>
                  <input
                    type="radio"
                    name="payment"
                    value="pay-later"
                    checked={selectedPayment === 'pay-later'}
                    onChange={(event) => setSelectedPayment(event.target.value)}
                  />
                  <span>Pay After Service Completion</span>
                </label>
              </div>
            </div>

            <button 
              className="provider-next-button"
              onClick={() => setShowConfirmationModal(true)}
            >
              Next
            </button>
          </div>
        ) : (
          <div className="booking-dashboard-content">
            <div className="booking-status-tabs">
              <button
                className={`status-tab ${activeBookingsTab === 'ongoing' ? 'active' : ''}`}
                onClick={() => setActiveBookingsTab('ongoing')}
            >
              On Going
            </button>
            <button 
                className={`status-tab ${activeBookingsTab === 'history' ? 'active' : ''}`}
                onClick={() => setActiveBookingsTab('history')}
            >
              History
            </button>
          </div>

            {activeBookingsTab === 'ongoing' ? (
              ongoingList.length ? (
                <div className="booking-list">
                  {ongoingList.map((booking) => {
                    const isExpanded = expandedBookingId === booking.id
                    return (
                      <div
                        key={booking.id}
                        className={`booking-card ${isExpanded ? 'expanded' : ''}`}
                        onClick={() =>
                          setExpandedBookingId((prev) => (prev === booking.id ? null : booking.id))
                        }
                      >
                        <div className="booking-card-header">
                          <div className="booking-card-provider">
                            <div className="booking-card-avatar">
                              <img src={booking.provider.avatar} alt={booking.provider.name} />
                            </div>
                            <div>
                              <h4>{booking.provider.name}</h4>
                              <span>{booking.provider.role}</span>
                            </div>
                          </div>
                          <div className="booking-card-status">
                            <span
                              className={`booking-status-pill ${
                                booking.status === 'history' ? 'completed' : 'confirmed'
                              }`}
                            >
                              {booking.statusLabel}
                            </span>
                            <span className="booking-card-price">₹ {booking.provider.price}</span>
                          </div>
                        </div>
                        {isExpanded && (
                          <div className="booking-card-details">
                            <div className="booking-detail-row">
                              <span className="detail-label">Service</span>
                              <span className="detail-value">{booking.service}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Preferred Date &amp; Time</span>
                              <span className="detail-value">{booking.schedule || 'Pending'}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Payment</span>
                              <span className="detail-value">{booking.paymentLabel}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Booking ID</span>
                              <span className="detail-value">{booking.reference}</span>
                            </div>
                            {booking.status !== 'history' && typeof setBookings === 'function' && (
                              <div className="booking-card-actions">
                                <button
                                  className="booking-card-action-button"
                                  onClick={(event) => {
                                    event.stopPropagation()
                                    setExpandedTrackingBooking(booking)
                                  }}
                                >
                                  Track Provider
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div className="booking-empty-content">
                  <div className="booking-empty-illustration">
                    <img src="/Booking_illustration.png" alt="No bookings" />
                  </div>
                  <div className="booking-empty-text">
                    <h3>No Recent Bookings</h3>
                    <p>Book an appointment and your booking details will show up here.</p>
                  </div>
                </div>
              )
            ) : (
              historyList.length ? (
                <div className="booking-list">
                  {historyList.map((booking) => {
                    const isExpanded = expandedBookingId === booking.id
                    return (
                      <div
                        key={booking.id}
                        className={`booking-card ${isExpanded ? 'expanded' : ''}`}
                        onClick={() =>
                          setExpandedBookingId((prev) => (prev === booking.id ? null : booking.id))
                        }
                      >
                        <div className="booking-card-header">
                          <div className="booking-card-provider">
                            <div className="booking-card-avatar">
                              <img src={booking.provider.avatar} alt={booking.provider.name} />
                            </div>
                            <div>
                              <h4>{booking.provider.name}</h4>
                              <span>{booking.provider.role}</span>
                            </div>
                          </div>
                          <div className="booking-card-status">
                            <span className="booking-status-pill completed">
                              {booking.statusLabel}
                            </span>
                            <span className="booking-card-price">₹ {booking.provider.price}</span>
                          </div>
                        </div>
                        {isExpanded && (
                          <div className="booking-card-details">
                            <div className="booking-detail-row">
                              <span className="detail-label">Service</span>
                              <span className="detail-value">{booking.service}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Preferred Date &amp; Time</span>
                              <span className="detail-value">{booking.schedule || 'Completed'}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Payment</span>
                              <span className="detail-value">{booking.paymentLabel}</span>
                            </div>
                            <div className="booking-detail-row">
                              <span className="detail-label">Booking ID</span>
                              <span className="detail-value">{booking.reference}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div className="booking-empty-content">
                  <div className="booking-empty-text">
                    <h3>No Past Bookings</h3>
                    <p>Once services are completed, they will move to history.</p>
                  </div>
                </div>
              )
            )}
          </div>
        )}

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onShowHome}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item active">
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text active">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item" onClick={onShowMessages}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="black"/>
              <circle cx="12" cy="10" r="1" fill="black"/>
              <circle cx="16" cy="10" r="1" fill="black"/>
            </svg>
            <span className="nav-text">Message</span>
          </div>
          <div className="nav-item" onClick={onShowProfile}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Me</span>
          </div>
        </div>

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showConfirmationModal && (
          <div className="provider-modal-overlay" onClick={() => setShowConfirmationModal(false)}>
            <div className="provider-modal-card" onClick={(event) => event.stopPropagation()}>
              <h3 className="provider-modal-title">Request confirmed</h3>
              <p className="provider-modal-message">
                we have got your request. We’ll notify you within 20 minutes about the booking status.
              </p>
              <button
                className="provider-modal-button"
                onClick={() => {
                  const reference = `PR-${Date.now().toString().slice(-6)}`
                  const prettySchedule = formData.schedule
                    ? new Date(formData.schedule).toLocaleString([], {
                        dateStyle: 'medium',
                        timeStyle: 'short'
                      })
                    : ''
                  const newBooking = {
                    id: Date.now(),
                    status: 'ongoing',
                    reference,
                    provider: selectedProvider,
                    service: formData.service || 'Not specified',
                    schedule: prettySchedule,
                    paymentLabel:
                      selectedPayment === 'pay-now' ? 'Paid online' : 'Pay after service completion',
                    statusLabel: 'Confirmed',
                    createdAt: new Date().toISOString()
                  }

                  if (typeof setBookings === 'function') {
                    setBookings((prev = []) => [...prev, newBooking])
                  }
                  setShowConfirmationModal(false)
                  setActiveBookingsTab('ongoing')
                  setExpandedBookingId(newBooking.id)
                  setFormData(initialFormState)
                  setSelectedPayment('pay-now')
                  if (onModeChange) {
                    onModeChange('dashboard')
                  }
                }}
              >
                OK
              </button>
            </div>
          </div>
        )}

        {expandedTrackingBooking && (
          <div className="tracking-overlay" onClick={() => setExpandedTrackingBooking(null)}>
            <div className="tracking-card" onClick={(event) => event.stopPropagation()}>
              <div className="tracking-map">
                <img src="/map-tracking.jpg" alt="Tracking map" />
              </div>
              <div className="tracking-info">
                <h3>Booking</h3>
                <p className="tracking-provider-name">{expandedTrackingBooking.provider.name}</p>
                <p className="tracking-provider-role">{expandedTrackingBooking.provider.role}</p>
              </div>
              <button className="tracking-close-button" onClick={() => setExpandedTrackingBooking(null)}>
                Close
              </button>
            </div>
          </div>
        )}

        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
            onShowSupport={() => {
              setShowSideMenu(false)
              setShowSupport(true)
            }}
            onShowPetInsurance={onShowPetInsurance}
          />
        )}
      </div>
    </div>
  )
}

export default Booking

