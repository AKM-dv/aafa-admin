struct node{
    int data;
    struct node* next;
}