import { useState } from 'react'
import './PetInfo.css'
import './Home.css'

function PetInfo({ petType, onBack, onShowPetPopup }) {
  const [petName, setPetName] = useState('')
  const [breed, setBreed] = useState('')
  const [birthday, setBirthday] = useState('')
  const [gender, setGender] = useState('')
  const [meals, setMeals] = useState('') // For cat only
  const [errors, setErrors] = useState({})

  const isDog = petType === 'dog'
  const isCat = petType === 'cat'

  const handleSubmit = (e) => {
    e.preventDefault()
    const newErrors = {}

    if (!petName.trim()) {
      newErrors.petName = `${isDog ? "Dog's" : "Cat's"} name is required`
    }
    if (!breed) {
      newErrors.breed = `Breed of ${isDog ? 'dog' : 'cat'} is required`
    }
    if (!birthday) {
      newErrors.birthday = `${isDog ? "Dog's" : "Cat's"} birthday is required`
    }
    if (!gender) {
      newErrors.gender = 'Gender is required'
    }
    if (isCat && !meals) {
      newErrors.meals = 'Number of meals is required'
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setErrors({})
    console.log('Pet info submitted:', { petType, petName, breed, birthday, gender, meals })
    // Navigate back or to next page
    if (onBack) {
      onBack()
    }
  }

  const isFormValid = petName.trim() && breed && birthday && gender && (isDog || meals)

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={onBack}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M15 18L9 12L15 6" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="logo-icon" />
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="pet-info-body">
          <form className="pet-info-form" onSubmit={handleSubmit}>
            <div className="pet-info-field">
              <label className="pet-info-label">
                {isDog ? "Dog's" : "Cat's"} Name<span className="required-asterisk">*</span>
              </label>
              <input
                type="text"
                className={`pet-info-input ${errors.petName ? 'error' : ''}`}
                value={petName}
                onChange={(e) => {
                  setPetName(e.target.value)
                  if (errors.petName) {
                    setErrors({ ...errors, petName: '' })
                  }
                }}
                placeholder={`Enter ${isDog ? "dog's" : "cat's"} name`}
              />
              {errors.petName && <p className="pet-info-error">{errors.petName}</p>}
            </div>

            <div className="pet-info-field">
              <label className="pet-info-label">
                Breed Of {isDog ? 'Dog' : 'Cat'}<span className="required-asterisk">*</span>
              </label>
              <div className="pet-info-select-wrapper">
                <select
                  className={`pet-info-select ${errors.breed ? 'error' : ''}`}
                  value={breed}
                  onChange={(e) => {
                    setBreed(e.target.value)
                    if (errors.breed) {
                      setErrors({ ...errors, breed: '' })
                    }
                  }}
                >
                  <option value="">Select breed</option>
                  {isDog ? (
                    <>
                      <option value="labrador">Labrador</option>
                      <option value="golden-retriever">Golden Retriever</option>
                      <option value="german-shepherd">German Shepherd</option>
                      <option value="bulldog">Bulldog</option>
                      <option value="poodle">Poodle</option>
                      <option value="beagle">Beagle</option>
                      <option value="rottweiler">Rottweiler</option>
                      <option value="yorkshire-terrier">Yorkshire Terrier</option>
                      <option value="other">Other</option>
                    </>
                  ) : (
                    <>
                      <option value="persian">Persian</option>
                      <option value="maine-coon">Maine Coon</option>
                      <option value="british-shorthair">British Shorthair</option>
                      <option value="ragdoll">Ragdoll</option>
                      <option value="bengal">Bengal</option>
                      <option value="siamese">Siamese</option>
                      <option value="american-shorthair">American Shorthair</option>
                      <option value="scottish-fold">Scottish Fold</option>
                      <option value="other">Other</option>
                    </>
                  )}
                </select>
                <svg className="pet-info-select-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6 9L12 15L18 9" stroke="#666666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              {errors.breed && <p className="pet-info-error">{errors.breed}</p>}
            </div>

            <div className="pet-info-field">
              <label className="pet-info-label">
                {isDog ? "Dog's" : "Cat's"} Birthday<span className="required-asterisk">*</span>
              </label>
              <div className="pet-info-select-wrapper">
                <select
                  className={`pet-info-select ${errors.birthday ? 'error' : ''}`}
                  value={birthday}
                  onChange={(e) => {
                    setBirthday(e.target.value)
                    if (errors.birthday) {
                      setErrors({ ...errors, birthday: '' })
                    }
                  }}
                >
                  <option value="">Select birthday</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                  <option value="2017">2017</option>
                  <option value="2016">2016</option>
                  <option value="2015">2015</option>
                  <option value="older">Older</option>
                </select>
                <svg className="pet-info-select-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6 9L12 15L18 9" stroke="#666666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              {errors.birthday && <p className="pet-info-error">{errors.birthday}</p>}
            </div>

            <div className="pet-info-field">
              <label className="pet-info-label">Is It A Boy Or A Girl?</label>
              <div className="pet-info-gender-options">
                <button
                  type="button"
                  className={`pet-info-gender-btn ${gender === 'boy' ? 'selected' : ''}`}
                  onClick={() => {
                    setGender('boy')
                    if (errors.gender) {
                      setErrors({ ...errors, gender: '' })
                    }
                  }}
                >
                  Boy
                </button>
                <button
                  type="button"
                  className={`pet-info-gender-btn ${gender === 'girl' ? 'selected' : ''}`}
                  onClick={() => {
                    setGender('girl')
                    if (errors.gender) {
                      setErrors({ ...errors, gender: '' })
                    }
                  }}
                >
                  Girl
                </button>
              </div>
              {errors.gender && <p className="pet-info-error">{errors.gender}</p>}
            </div>

            {isCat && (
              <div className="pet-info-field">
                <label className="pet-info-label">How Many Meal Does Your Cat Have?</label>
                <div className="pet-info-meals-options">
                  <button
                    type="button"
                    className={`pet-info-meal-btn ${meals === '1' ? 'selected' : ''}`}
                    onClick={() => {
                      setMeals('1')
                      if (errors.meals) {
                        setErrors({ ...errors, meals: '' })
                      }
                    }}
                  >
                    1
                  </button>
                  <button
                    type="button"
                    className={`pet-info-meal-btn ${meals === '2' ? 'selected' : ''}`}
                    onClick={() => {
                      setMeals('2')
                      if (errors.meals) {
                        setErrors({ ...errors, meals: '' })
                      }
                    }}
                  >
                    2
                  </button>
                  <button
                    type="button"
                    className={`pet-info-meal-btn ${meals === '3' ? 'selected' : ''}`}
                    onClick={() => {
                      setMeals('3')
                      if (errors.meals) {
                        setErrors({ ...errors, meals: '' })
                      }
                    }}
                  >
                    3
                  </button>
                  <button
                    type="button"
                    className={`pet-info-meal-btn ${meals === '4' ? 'selected' : ''}`}
                    onClick={() => {
                      setMeals('4')
                      if (errors.meals) {
                        setErrors({ ...errors, meals: '' })
                      }
                    }}
                  >
                    4
                  </button>
                </div>
                {errors.meals && <p className="pet-info-error">{errors.meals}</p>}
              </div>
            )}

            <button
              type="submit"
              className={`pet-info-next-button ${!isFormValid ? 'disabled' : ''}`}
              disabled={!isFormValid}
            >
              Next
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default PetInfo

