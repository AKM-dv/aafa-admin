import { useState } from 'react'
import './GetStarted.css'
import OTP from './OTP'
import Home from './Home'

function GetStarted({ onBack, onLogout, userData, setUserData }) {
  const [phoneNumber, setPhoneNumber] = useState('')
  const [countryCode, setCountryCode] = useState('+91')
  const [showOTP, setShowOTP] = useState(false)
  const [showHome, setShowHome] = useState(false)
  const [phoneError, setPhoneError] = useState('')

  const handlePhoneChange = (e) => {
    const value = e.target.value.replace(/\D/g, '')
    if (value.length <= 10) {
      setPhoneNumber(value)
      if (value.length > 0 && value.length < 10) {
        setPhoneError('Phone number must be 10 digits')
      } else {
        setPhoneError('')
      }
    }
  }

  const handleContinue = () => {
    if (phoneNumber.length === 10) {
      setShowOTP(true)
    } else {
      setPhoneError('Phone number must be 10 digits')
    }
  }

  const isValidPhone = phoneNumber.length === 10

  if (showHome) {
    return <Home 
      onLogout={onLogout} 
      userData={userData}
      setUserData={setUserData}
    />
  }

  if (showOTP) {
    return (
      <OTP 
        onBack={() => setShowOTP(false)} 
        phoneNumber={phoneNumber} 
        countryCode={countryCode} 
        onLogout={onLogout}
        onVerifySuccess={() => setShowHome(true)}
      />
    )
  }

  return (
    <div className="get-started-container">
      <div className="get-started-content">
        <div className="header-section">
          <button className="back-button" onClick={onBack}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="18" y1="12" x2="6" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <path d="M6 12L12 6M6 12L12 18" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        <div className="top-section">
          <div className="phone-icon-container">
            <img src="/phone.png" alt="Phone" className="phone-icon" />
          </div>

          <div className="heading-with-stars">
            <div className="stars-container">
              <span className="star-icon">✦</span>
              <span className="star-icon">✦</span>
              <span className="star-icon">✦</span>
            </div>
            <h1 className="get-started-heading">GET STARTED</h1>
            <div className="stars-container">
              <span className="star-icon">✦</span>
              <span className="star-icon">✦</span>
            </div>
          </div>

          <div className="description-section">
            <p className="description-text">We'll send you a text with a verification code.</p>
            <p className="description-text">Sign in and make pet parenting easy!</p>
          </div>
        </div>

        <div className="form-section">
          <div className="phone-input-wrapper">
            <div className={`phone-input-container ${phoneError ? 'error' : ''}`}>
              <div className="country-code-selector">
                <span>{countryCode}</span>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 4.5L6 7.5L9 4.5" stroke="#666666" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <input
                type="tel"
                className="phone-input"
                placeholder="Phone number"
                value={phoneNumber}
                onChange={handlePhoneChange}
                maxLength="10"
              />
            </div>
            {phoneError && <p className="error-message">{phoneError}</p>}
          </div>

          <button 
            className={`continue-button ${!isValidPhone ? 'disabled' : ''}`} 
            onClick={handleContinue}
            disabled={!isValidPhone}
          >
            Continue
          </button>

          <p className="terms-text">
            By continuing. You agree to our T&C and privacy policy
          </p>
        </div>

        <div className="illustration-bottom">
          <img 
            src="/get.png" 
            alt="Care illustration" 
            className="get-started-illustration"
          />
        </div>
      </div>
    </div>
  )
}

export default GetStarted