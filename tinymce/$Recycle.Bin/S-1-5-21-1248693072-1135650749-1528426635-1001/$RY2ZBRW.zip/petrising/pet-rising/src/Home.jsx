import { useState, useEffect } from 'react'
import './Home.css'
import Booking from './Booking'
import Messages from './Messages'
import Profile from './Profile'
import ServiceAddress from './ServiceAddress'
import SideMenu from './SideMenu'
import Support from './Support'
import PetInfo from './PetInfo'
import PetInsurance from './PetInsurance'

function Home({ onLogout, userData, setUserData }) {
  const [showAllHeroes, setShowAllHeroes] = useState(false)
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0)
  const [showPetPopup, setShowPetPopup] = useState(false)
  const [selectedPet, setSelectedPet] = useState(null)
  const [showPetInfo, setShowPetInfo] = useState(false)
  const [petInfoType, setPetInfoType] = useState(null)
  const [showBooking, setShowBooking] = useState(false)
  const [showMessages, setShowMessages] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [showServiceAddress, setShowServiceAddress] = useState(false)
  const [showSupport, setShowSupport] = useState(false)
  const [showPetInsurance, setShowPetInsurance] = useState(false)
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [bookingMode, setBookingMode] = useState('dashboard')
  const [bookings, setBookings] = useState([])
  const [preselectedServiceName, setPreselectedServiceName] = useState('')
  const [selectedServiceCategory, setSelectedServiceCategory] = useState(null)

  const handlePetCardClick = (pet) => {
    if (!pet) return
    setSelectedPet(pet)
  }

  const handlePetConfirm = () => {
    if (!selectedPet) return
    setPetInfoType(selectedPet)
    setShowPetPopup(false)
    setShowPetInfo(true)
    setSelectedPet(null)
  }

  const reviews = [
    {
      name: 'Nidhi',
      rating: 4.9,
      comment: 'Great Services! The pets really seem to enjoy their time out here. Highly recommended it to all of you out there looking for good grooming services for your pets.'
    },
    {
      name: 'Ankita',
      rating: 4.8,
      comment: 'Excellent pet care service! The staff is very professional and caring. My dog absolutely loves the grooming sessions. Will definitely come back again!'
    },
    {
      name: 'Aakarshan',
      rating: 4.7,
      comment: 'Outstanding service! The vet on call feature is amazing and very convenient. My pet received timely medical attention. Highly satisfied with the experience.'
    },
    {
      name: 'Rahul',
      rating: 5.0,
      comment: 'Best pet service in town! The dog walking service is fantastic and my pet stays active and healthy. The team is friendly and trustworthy. Highly recommend!'
    }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentReviewIndex((prevIndex) => (prevIndex + 1) % reviews.length)
    }, 4000)

    return () => clearInterval(interval)
  }, [reviews.length])

  if (showPetInsurance) {
    return (
      <PetInsurance 
        onBack={() => setShowPetInsurance(false)}
        onShowBooking={() => {
          setShowPetInsurance(false)
          setBookingMode('dashboard')
          setShowBooking(true)
        }}
        onShowMessages={() => {
          setShowPetInsurance(false)
          setShowMessages(true)
        }}
        onShowProfile={() => {
          setShowPetInsurance(false)
          setShowProfile(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowPetInsurance(false)
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  if (showPetInfo) {
    return (
      <PetInfo 
        petType={petInfoType}
        onBack={() => {
          setShowPetInfo(false)
          setPetInfoType(null)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
      />
    )
  }

  if (showSupport) {
    return (
      <Support 
        onBack={() => setShowSupport(false)}
        onShowBooking={() => {
          setShowSupport(false)
          setBookingMode('dashboard')
          setShowBooking(true)
        }}
        onShowMessages={() => {
          setShowSupport(false)
          setShowMessages(true)
        }}
        onShowProfile={() => {
          setShowSupport(false)
          setShowProfile(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
        onShowPetInsurance={() => {
          setShowSupport(false)
          setShowPetInsurance(true)
        }}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowSupport(false)
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  if (showServiceAddress) {
    return (
      <ServiceAddress 
        onBack={() => setShowServiceAddress(false)}
        onShowBooking={() => {
          setShowServiceAddress(false)
          setBookingMode('dashboard')
          setShowBooking(true)
        }}
        onShowMessages={() => {
          setShowServiceAddress(false)
          setShowMessages(true)
        }}
        onShowProfile={() => {
          setShowServiceAddress(false)
          setShowProfile(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
        onShowPetInsurance={() => {
          setShowServiceAddress(false)
          setShowPetInsurance(true)
        }}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowServiceAddress(false)
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  if (showProfile) {
    return (
      <Profile 
        onShowHome={() => setShowProfile(false)}
        onShowBooking={() => {
          setShowProfile(false)
          setBookingMode('dashboard')
          setShowBooking(true)
        }}
        onShowMessages={() => {
          setShowProfile(false)
          setShowMessages(true)
        }}
        onShowServiceAddress={() => {
          setShowProfile(false)
          setShowServiceAddress(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        onLogout={onLogout}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        userData={userData}
        setUserData={setUserData}
        onShowPetInsurance={() => {
          setShowProfile(false)
          setShowPetInsurance(true)
        }}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowProfile(false)
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  if (showMessages) {
    return (
      <Messages 
        onShowHome={() => setShowMessages(false)}
        onShowBooking={() => {
          setShowMessages(false)
          setBookingMode('dashboard')
          setShowBooking(true)
        }}
        onShowProfile={() => {
          setShowMessages(false)
          setShowProfile(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
        onShowPetInsurance={() => {
          setShowMessages(false)
          setShowPetInsurance(true)
        }}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowMessages(false)
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  if (showBooking) {
    return (
      <Booking 
        mode={bookingMode}
        onModeChange={setBookingMode}
        bookings={bookings}
        setBookings={setBookings}
        selectedServiceCategory={selectedServiceCategory}
        setSelectedServiceCategory={setSelectedServiceCategory}
        preselectedServiceName={preselectedServiceName}
        setPreselectedServiceName={setPreselectedServiceName}
        onShowHome={() => {
          setShowBooking(false)
          setBookingMode('dashboard')
          setPreselectedServiceName('')
        }}
        onShowMessages={() => {
          setShowBooking(false)
          setBookingMode('dashboard')
          setShowMessages(true)
        }}
        onShowProfile={() => {
          setShowBooking(false)
          setBookingMode('dashboard')
          setShowProfile(true)
        }}
        onShowPetPopup={() => setShowPetPopup(true)}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
        onShowPetInsurance={() => {
          setShowBooking(false)
          setBookingMode('dashboard')
          setShowPetInsurance(true)
        }}
        onShowPetInfo={(petType) => {
          setPetInfoType(petType)
          setShowBooking(false)
          setBookingMode('dashboard')
          setShowPetInfo(true)
          setSelectedPet(null)
        }}
      />
    )
  }

  return (
    <div className="home-container" style={{ position: 'relative' }}>
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="logo-icon" />
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="home-body">
          <div className="service-cards-row">
            <div className="service-card service-card--primary" style={{ backgroundImage: 'url(/grooming.jpg)' }}>
              <div className="service-card-overlay"></div>
              <div className="service-card-content">
                <h3 className="service-card-title">
                  Pet grooming services<br />At Home
                </h3>
                <button
                  className="service-book-btn"
                  onClick={() => {
                    setPreselectedServiceName('Pet Grooming')
                    setBookingMode('form')
                    setShowBooking(true)
                  }}
                >
                  Book Now
                </button>
              </div>
            </div>




            <div
              className="service-card service-card--image"
              style={{ backgroundImage: 'url(/veton-call.jpg)' }}
            >
              <div className="service-card-content">
                <h3 className="service-card-title">Vets on call starts from</h3>
                <div className="service-price">
                  <span className="price-strikethrough">499</span>
                  <span className="price-current">/ 159</span>
                </div>
                <button
                  className="service-book-btn"
                  onClick={() => {
                    setPreselectedServiceName('Vet on Call')
                    setBookingMode('form')
                    setShowBooking(true)
                  }}
                >
                  Book Now
                </button>
              </div>
            </div>

            <div className="service-card service-card--primary" style={{ backgroundImage: 'url(/Dog-walking.jpg)' }}>
              <div className="service-card-overlay"></div>
              <div className="service-card-content">
                <h3 className="service-card-title">
                  Daily Dog Walking<br />Packages
                </h3>
                <button
                  className="service-book-btn"
                  onClick={() => {
                    setPreselectedServiceName('Dog Walking')
                    setBookingMode('form')
                    setShowBooking(true)
                  }}
                >
                  Book Now
                </button>
              </div>
            </div>

            <div className="service-card service-card--primary" style={{ backgroundImage: 'url(/premium-home.jpg)' }}>
              <div className="service-card-overlay"></div>
              <div className="service-card-content">
                <h3 className="service-card-title">
                  Premium Pet Boarding<br />at Partner Homes
                </h3>
                <button
                  className="service-book-btn"
                  onClick={() => {
                    setPreselectedServiceName('Pet Boarding')
                    setBookingMode('form')
                    setShowBooking(true)
                  }}
                >
                  Book Now
                </button>
              </div>
            </div>
          </div>

          <div className="services-section">
            <h3 className="section-title">Services</h3>
            <div className="services-grid">
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('dogTraining')
                  setPreselectedServiceName('Dog Training')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('dogTraining')
                    setPreselectedServiceName('Dog Training')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <svg className="service-icon dog-training-icon" width="28" height="28" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill="#000" fillRule="evenodd" d="M24 3.5c2.224 0 4.366.74 6.338 2.069C40.185 6.394 46.5 14.489 46.5 21c0 1.71-.416 4.103-2.092 6.091q-.101.12-.208.238c-1.426-7.176-4.642-13.064-8.688-16.385q.414.615.804 1.27C39.49 17.546 41.5 24.9 41.5 33.048v.016c0 1.44 0 4.34-2.252 6.864C36.986 42.462 32.564 44.5 24 44.5s-12.986-2.038-15.248-4.572C6.5 37.405 6.5 34.504 6.5 33.064v-.016c0-8.149 2.01-15.502 5.184-20.834q.39-.655.804-1.27C8.442 14.266 5.226 20.153 3.8 27.329a8 8 0 0 1-.208-.238C1.917 25.103 1.5 22.71 1.5 21c0-6.51 6.315-14.606 16.162-15.431C19.634 4.239 21.775 3.5 24 3.5M18 18a2 2 0 0 0-2 2v1a2 2 0 1 0 4 0v-1a2 2 0 0 0-2-2m12 0a2 2 0 0 1 2 2v1a2 2 0 1 1-4 0v-1a2 2 0 0 1 2-2M19.5 29.369c0 1.83 1.31 3.318 3 3.885v2.278a2.5 2.5 0 0 1-.312.297c-.378.302-1.052.671-2.188.671s-1.81-.369-2.188-.671a2 2 0 0 1-.484-.527a1.5 1.5 0 0 0-2.67 1.369l.002.003c.295.585.772 1.092 1.278 1.497c.872.698 2.198 1.329 4.062 1.329c1.82 0 3.128-.602 4-1.28c.872.678 2.18 1.28 4 1.28c1.864 0 3.19-.631 4.062-1.329c.515-.411.981-.905 1.279-1.499a1.514 1.514 0 0 0-.67-2.014a1.5 1.5 0 0 0-1.998.644l-.004.005c-.03.05-.184.284-.481.522c-.378.302-1.052.671-2.188.671s-1.81-.369-2.188-.671a2.5 2.5 0 0 1-.312-.297v-2.278c1.69-.567 3-2.055 3-3.885v-.008c0-.098 0-.314-.103-.554c-.11-.256-.314-.491-.641-.686c-.623-.37-1.74-.621-3.756-.621s-3.133.25-3.756.62c-.327.196-.53.431-.64.687a1.35 1.35 0 0 0-.104.554z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>Dog Training</span>
              </div>
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('catTraining')
                  setPreselectedServiceName('Cat Training')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('catTraining')
                    setPreselectedServiceName('Cat Training')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <svg className="service-icon cat-training-icon" width="28" height="28" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g fill="none">
                      <path stroke="#000" strokeLinecap="round" strokeWidth="4" d="M42 26C42 34.8366 33.9411 42 24 42C14.0589 42 6 34.8366 6 26M15 12.1405C17.6476 10.7792 20.7214 10 24 10C27.2786 10 30.3524 10.7792 33 12.1405" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M6 26V8.48814C6 6.757 8.05005 5.84346 9.33729 7.00098L15 12.093" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M42 26V8.48814C42 6.757 39.9499 5.84346 38.6627 7.00098L33 12.093" />
                      <circle cx="30" cy="22" r="2" fill="#000" />
                      <circle cx="18" cy="22" r="2" fill="#000" />
                      <circle cx="24" cy="28" r="2" fill="#000" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M16 30L4 31" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M19 35L7 41" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M32 30L44 31" />
                      <path stroke="#000" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M29 35L41 41" />
                    </g>
                  </svg>
                </div>
                <span>Cat Training</span>
              </div>
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('petGrooming')
                  setPreselectedServiceName('Pet Grooming')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('petGrooming')
                    setPreselectedServiceName('Pet Grooming')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <img src="/petgrooming.png" alt="Pet Grooming" className="service-icon" />
                </div>
                <span>Pet Grooming</span>
              </div>
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('vetOnCall')
                  setPreselectedServiceName('Vet on Call')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('vetOnCall')
                    setPreselectedServiceName('Vet on Call')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <img src="/vet.png" alt="Vet on Call" className="service-icon" />
                </div>
                <span>Vet on Call</span>
              </div>
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('dogWalking')
                  setPreselectedServiceName('Dog Walking')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('dogWalking')
                    setPreselectedServiceName('Dog Walking')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <img src="/dogwalk.png" alt="Dog Walking" className="service-icon dogwalk-icon" />
                </div>
                <span>Dog Walking</span>
              </div>
              <div
                className="service-card-item"
                role="button"
                tabIndex={0}
                onClick={() => {
                  setSelectedServiceCategory('petBoarding')
                  setPreselectedServiceName('Pet Boarding')
                  setBookingMode('serviceCatalog')
                  setShowBooking(true)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    setSelectedServiceCategory('petBoarding')
                    setPreselectedServiceName('Pet Boarding')
                    setBookingMode('serviceCatalog')
                    setShowBooking(true)
                  }
                }}
              >
                <div className="service-icon-bg">
                  <img src="/petboarding.png" alt="Pet Boarding" className="service-icon" />
                </div>
                <span>Pet Boarding</span>
              </div>
            </div>
          </div>

          <div className="how-it-works-section">
            <h3 className="section-title">How does it work?</h3>
            <div className="how-it-works-steps">
              <div className="step-connector-line"></div>
              <div className="step-item">
                <div className="step-icon">
                  <svg className="step-icon-svg" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="11" cy="11" r="8" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M21 21L16.65 16.65" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <p className="step-text">
                  Search pet cares<br />
                  heroes by location<br />
                  and services
                </p>
              </div>
              <div className="step-item">
                <div className="step-icon">
                  <svg className="step-icon-svg" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="4" width="18" height="18" rx="2" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 10H21" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M8 2V6" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M16 2V6" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="12" cy="15" r="1" fill="#F55810"/>
                    <circle cx="16" cy="15" r="1" fill="#F55810"/>
                    <circle cx="8" cy="15" r="1" fill="#F55810"/>
                  </svg>
                </div>
                <p className="step-text">
                  Schedule your<br />
                  appointment at<br />
                  home
                </p>
              </div>
              <div className="step-item">
                <div className="step-icon">
                  <img src="/sit-relax.png" alt="Sit back and relax" className="step-icon-img" />
                </div>
                <p className="step-text">
                  Sit back and relax!<br />
                  your pet hero is on<br />
                  the way
                </p>
              </div>
            </div>
          </div>

          <div className="pet-heroes-section">
            <h3 className="section-title">Pet Heroes of the month</h3>
            <div className="hero-cards-container">
              <div className="hero-card">
                <div className="hero-profile-image">
                  <img src="/hero1.png" alt="Debjeet Chakraborty" />
                </div>
                <div className="hero-info">
                  <h4 className="hero-name">Debjeet Chakraborty</h4>
                  <p className="hero-profession">Groomer</p>
                  <div className="hero-rating">
                    <div className="stars-container">
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star half-filled">★</span>
                    </div>
                    <span className="rating-number">4.46</span>
                  </div>
                  <p className="appointments-completed">Appointmenet Completed -3333</p>
                </div>
              </div>

              <div className="hero-card">
                <div className="hero-profile-image">
                  <img src="/hero2.png" alt="K Pavan Kumar" />
                </div>
                <div className="hero-info">
                  <h4 className="hero-name">K Pavan Kumar</h4>
                  <p className="hero-profession">Groomer</p>
                  <div className="hero-rating">
                    <div className="stars-container">
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star quarter-filled">★</span>
                    </div>
                    <span className="rating-number">4.26</span>
                  </div>
                  <p className="appointments-completed">Appointmenet Completed -5298</p>
                </div>
              </div>

              <div className="hero-card">
                <div className="hero-profile-image">
                  <img src="/hero3.png" alt="Dr Manu Jaiswal" />
                </div>
                <div className="hero-info">
                  <h4 className="hero-name">Dr Manu Jaiswal</h4>
                  <p className="hero-profession">Veterinarian</p>
                  <div className="hero-rating">
                    <div className="stars-container">
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                      <span className="star filled">★</span>
                    </div>
                    <span className="rating-number">4.9</span>
                  </div>
                  <p className="appointments-completed">Appointmenet Completed -2925</p>
                </div>
              </div>

              {showAllHeroes && (
                <>
                  {/* Additional hero cards can be added here when needed */}
                </>
              )}
            </div>

            {!showAllHeroes && (
              <div className="view-more-section" onClick={() => setShowAllHeroes(true)}>
                <p className="view-more-text">View More</p>
                <svg className="view-more-arrow" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 6L8 10L12 6" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
            )}
          </div>

          <div className="safety-section">
            <div className="safety-title-container">
              <svg className="safety-shield-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L4 5V11C4 16.55 7.16 21.74 12 23C16.84 21.74 20 16.55 20 11V5L12 2Z" fill="#F55810"/>
                <path d="M9 12L11 14L15 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <h3 className="safety-title">Pet Services at Home with Safety</h3>
            </div>
            <div className="safety-measures-grid">
              <div className="safety-measure-item">
                <div className="safety-icon-circle">
                  <svg className="safety-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C10.34 2 9 3.34 9 5V7C9 7.55 8.55 8 8 8H6C5.45 8 5 8.45 5 9V19C5 19.55 5.45 20 6 20H18C18.55 20 19 19.55 19 19V9C19 8.45 18.55 8 18 8H16C15.45 8 15 7.55 15 7V5C15 3.34 13.66 2 12 2Z" fill="black"/>
                    <path d="M10 12H14" stroke="black" strokeWidth="1.5" strokeLinecap="round"/>
                    <circle cx="12" cy="16" r="1" fill="black"/>
                  </svg>
                </div>
                <p className="safety-text">Sanitized kits and Tools</p>
              </div>

              <div className="safety-measure-item">
                <div className="safety-icon-circle">
                  <svg className="safety-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="8" y="2" width="8" height="3" rx="1" fill="black"/>
                    <rect x="10" y="5" width="4" height="14" rx="2" fill="black"/>
                    <rect x="11" y="7" width="2" height="10" fill="white"/>
                    <circle cx="12" cy="19" r="1" fill="black"/>
                  </svg>
                </div>
                <p className="safety-text">Temperature Recorder</p>
              </div>

              <div className="safety-measure-item">
                <div className="safety-icon-circle">
                  <svg className="safety-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" fill="black"/>
                    <path d="M12 9L14 11L16 9" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <p className="safety-text">Updated status on Arogya Setu App</p>
              </div>

              <div className="safety-measure-item">
                <div className="safety-icon-circle">
                  <svg className="safety-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 10H6C5.45 10 5 10.45 5 11V19C5 19.55 5.45 20 6 20H18C18.55 20 19 19.55 19 19V11C19 10.45 18.55 10 18 10Z" fill="black"/>
                    <path d="M12 2V6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M8 2V6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M16 2V6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M12 13V17" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                </div>
                <p className="safety-text">One Time Usable Products</p>
              </div>
            </div>
          </div>

          <div className="customer-reviews-section">
            <h3 className="section-title">What our customer says</h3>
            <div className="reviews-container">
              <div className="review-card" key={currentReviewIndex}>
                <div className="review-header">
                  <h4 className="reviewer-name">{reviews[currentReviewIndex].name}</h4>
                  <div className="review-rating">
                    <div className="review-stars">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className="review-star filled">★</span>
                      ))}
                    </div>
                    <span className="review-rating-number">{reviews[currentReviewIndex].rating}</span>
                  </div>
                </div>
                <p className="review-text">{reviews[currentReviewIndex].comment}</p>
              </div>
            </div>
          </div>

          <div className="bottom-navigation">
            <div className="nav-item active" onClick={() => setShowBooking(false)}>
              <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="nav-text active">Home</span>
            </div>
            <div
              className="nav-item"
              onClick={() => {
                setBookingMode('dashboard')
                setShowBooking(true)
              }}
            >
              <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="nav-text">Booking</span>
            </div>
          <div className="nav-center-action" onClick={() => setShowPetPopup(true)}>
            <div className={`center-action-circle ${!selectedPet && !showPetPopup ? 'highlight' : ''}`}>
                <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                  <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                  <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                  <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                  <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                  <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
                </svg>
                <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
            </div>
            <div className="nav-item" onClick={() => setShowMessages(true)}>
              <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="8" cy="10" r="1" fill="black"/>
                <circle cx="12" cy="10" r="1" fill="black"/>
                <circle cx="16" cy="10" r="1" fill="black"/>
              </svg>
              <span className="nav-text">Message</span>
            </div>
            <div className="nav-item" onClick={() => setShowProfile(true)}>
              <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="nav-text">Me</span>
            </div>
          </div>

          {showPetPopup && (
            <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
              <div className="popup-content" onClick={(e) => e.stopPropagation()}>
                <h2 className="popup-title">Select Your Pet</h2>
                <div className="pet-selection-cards">
                  <div 
                    className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                    onClick={() => handlePetCardClick('dog')}
                  >
                    <div className="pet-card-overlay-dog"></div>
                    <div className="pet-card-content">
                      <span className="pet-card-text">DOG</span>
                    </div>
                  </div>
                  <div 
                    className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                    onClick={() => handlePetCardClick('cat')}
                  >
                    <div className="pet-card-overlay-cat"></div>
                    <div className="pet-card-content">
                      <span className="pet-card-text">CAT</span>
                    </div>
                  </div>
                </div>
                <div className="popup-buttons">
                  <button 
                    className="popup-button next-button"
                    onClick={handlePetConfirm}
                    disabled={!selectedPet}
                  >
                    Next
                  </button>
                  <button 
                    className="popup-button cancel-button"
                    onClick={() => {
                      setShowPetPopup(false)
                      setSelectedPet(null)
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
            onShowSupport={() => {
              setShowSideMenu(false)
              setShowSupport(true)
            }}
            onShowPetInsurance={() => {
              setShowSideMenu(false)
              setShowPetInsurance(true)
            }}
          />
        )}
      </div>
    </div>
  )
}

export default Home
