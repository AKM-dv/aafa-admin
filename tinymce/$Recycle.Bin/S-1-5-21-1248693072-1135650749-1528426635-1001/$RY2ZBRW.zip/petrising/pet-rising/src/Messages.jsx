import { useState } from 'react'
import './Messages.css'
import './Home.css'
import Support from './Support'

function Messages({ onShowHome, onShowBooking, onShowProfile, onShowPetPopup, showPetPopup, selectedPet, setSelectedPet, setShowPetPopup, onLogout, onShowPetInsurance, onShowPetInfo }) {
  const [showSupport, setShowSupport] = useState(false)
  const [messages, setMessages] = useState([
    {
      id: 'm-1',
      sender: 'support',
      text: 'Hi Nidhi! This is Petifi support.',
      timestamp: '09:01 AM'
    },
    {
      id: 'm-2',
      sender: 'support',
      text: 'How can we help you today?',
      timestamp: '09:01 AM'
    },
    {
      id: 'm-3',
      sender: 'user',
      text: 'I need to reschedule my grooming appointment.',
      timestamp: '09:02 AM'
    },
    {
      id: 'm-4',
      sender: 'support',
      text: 'Sure, please share your preferred date and time and I will check availability.',
      timestamp: '09:03 AM'
    }
  ])
  const [messageDraft, setMessageDraft] = useState('')

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  if (showSupport) {
    return (
      <Support 
        onBack={() => setShowSupport(false)}
        onShowBooking={() => {
          setShowSupport(false)
          onShowBooking()
        }}
        onShowMessages={() => {
          setShowSupport(false)
        }}
        onShowProfile={() => {
          setShowSupport(false)
          onShowProfile()
        }}
        onShowPetPopup={onShowPetPopup}
        showPetPopup={showPetPopup}
        selectedPet={selectedPet}
        setSelectedPet={setSelectedPet}
        setShowPetPopup={setShowPetPopup}
        onLogout={onLogout}
      />
    )
  }

  const handleSendMessage = (event) => {
    event.preventDefault()
    if (!messageDraft.trim()) return

    const newMessage = {
      id: `m-${Date.now()}`,
      sender: 'user',
      text: messageDraft.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }

    setMessages((prev) => [...prev, newMessage])

    setMessageDraft('')
    setTimeout(() => {
      const container = document.querySelector('.chat-messages')
      if (container) {
        container.scrollTop = container.scrollHeight
      }
    }, 0)
  }

  const handleBackToProfile = () => {
    if (typeof onShowProfile === 'function') {
      onShowProfile()
    }
  }

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="chat-header-bar">
          <button className="chat-back-button" onClick={handleBackToProfile}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M15 18L9 12L15 6" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div className="chat-header-texts">
            <h2 className="chat-header-title">Chat with Pet Rising Star</h2>
            <span className="chat-header-subtitle">Customer Support</span>
          </div>
        </header>

        <div className="messages-body">
          <div className="chat-wrapper">
            <div className="chat-messages">
              {messages.map((message) => (
                <div key={message.id} className={`chat-row ${message.sender}`}>
                  {message.sender === 'support' && <div className="chat-avatar">P</div>}
                  <div className={`chat-bubble ${message.sender}`}>
                    <p className="chat-message-text">{message.text}</p>
                    <span className="chat-message-time">{message.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <form className="chat-input-bar" onSubmit={handleSendMessage}>
            <input
              className="chat-input"
              type="text"
              placeholder="Type your message..."
              value={messageDraft}
              onChange={(event) => setMessageDraft(event.target.value)}
            />
            <button type="submit" className="chat-send-button">
              Send
            </button>
          </form>
        </div>

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onShowHome}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item" onClick={onShowBooking}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item active">
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="#F55810" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="#F55810"/>
              <circle cx="12" cy="10" r="1" fill="#F55810"/>
              <circle cx="16" cy="10" r="1" fill="#F55810"/>
            </svg>
            <span className="nav-text active">Message</span>
          </div>
          <div className="nav-item" onClick={onShowProfile}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Me</span>
          </div>
        </div>

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Messages

