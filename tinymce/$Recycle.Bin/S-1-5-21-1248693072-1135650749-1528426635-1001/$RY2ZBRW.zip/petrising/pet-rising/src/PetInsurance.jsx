import { useState } from 'react'
import './PetInsurance.css'
import './Home.css'
import SideMenu from './SideMenu'

function PetInsurance({ onBack, onShowBooking, onShowMessages, onShowProfile, onShowPetPopup, showPetPopup, selectedPet, setSelectedPet, setShowPetPopup, onLogout, onShowPetInfo }) {
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [petType, setPetType] = useState('dog')
  const [breed, setBreed] = useState('')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [contact, setContact] = useState('')
  const [petAge, setPetAge] = useState('')
  const [errors, setErrors] = useState({})

  const handlePetSelection = (pet) => {
    if (!pet) return
    if (setSelectedPet) {
      setSelectedPet(pet)
    }
    if (onShowPetInfo) {
      onShowPetInfo(pet)
    }
    if (setShowPetPopup) {
      setShowPetPopup(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const newErrors = {}

    if (!breed) {
      newErrors.breed = 'Pet breed is required'
    }
    if (!name.trim()) {
      newErrors.name = 'Your name is required'
    }
    if (!email.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Please enter a valid email address'
    }
    if (!contact.trim()) {
      newErrors.contact = 'Contact number is required'
    } else if (!/^\d{10}$/.test(contact)) {
      newErrors.contact = 'Contact number must be 10 digits'
    }
    if (!petAge.trim()) {
      newErrors.petAge = 'Pet age is required'
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setErrors({})
    console.log('Pet insurance form submitted:', { petType, breed, name, email, contact, petAge })
    // Handle form submission
  }

  const isFormValid = breed && name.trim() && email.trim() && contact.trim() && petAge.trim()

  return (
    <div className="home-container">
      <div className="home-content">
        <header className="home-header">
          <button className="hamburger-menu" onClick={() => setShowSideMenu(true)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="3" y1="6" x2="21" y2="6" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="12" x2="21" y2="12" stroke="black" strokeWidth="2" strokeLinecap="round"/>
              <line x1="3" y1="18" x2="21" y2="18" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          <div className="home-logo">
            <img src="/petrising-logo.png" alt="Petifi Logo" className="logo-icon" />
          </div>
          <button className="profile-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="11" stroke="black" strokeWidth="2"/>
              <circle cx="12" cy="9" r="3" stroke="black" strokeWidth="2"/>
              <path d="M6 19C6 16 8 14 12 14C16 14 18 16 18 19" stroke="black" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="pet-insurance-body">
          <div className="pet-insurance-hero">
            <img src="/petinsurance.png" alt="Pet Insurance" className="pet-insurance-hero-img" />
            <div className="pet-insurance-hero-text">
              <h2 className="pet-insurance-hero-title">Best Pet Insurance For Your Pet</h2>
              <p className="pet-insurance-hero-subtitle">Pet Insurance Plans that suits best your Dog well being</p>
              <ul className="pet-insurance-hero-list">
                <li>Plans starting at Rs 2 per day</li>
                <li>Use any vet, anywhere</li>
                <li>More than a million pets protected</li>
              </ul>
            </div>
          </div>

          <div className="pet-insurance-form-card">
            <h3 className="pet-insurance-form-title">The Best Pet Insurance for a Lifetime of Care</h3>
            <p className="pet-insurance-form-subtitle">Fill in your details below to receive policy plan quotation</p>
            
            <form className="pet-insurance-form" onSubmit={handleSubmit}>
              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Pet Type?</label>
                <div className="pet-insurance-pet-type-selector">
                  <button
                    type="button"
                    className={`pet-insurance-pet-type-btn ${petType === 'dog' ? 'selected' : ''}`}
                    onClick={() => setPetType('dog')}
                  >
                    <span className="pet-insurance-pet-type-icon">🐕</span>
                    <span>Dog</span>
                  </button>
                  <button
                    type="button"
                    className={`pet-insurance-pet-type-btn ${petType === 'cat' ? 'selected' : ''}`}
                    onClick={() => setPetType('cat')}
                  >
                    <span className="pet-insurance-pet-type-icon">🐈</span>
                    <span>Cat</span>
                  </button>
                </div>
              </div>

              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Pet Breed?</label>
                <div className="pet-insurance-select-wrapper">
                  <select
                    className={`pet-insurance-select ${errors.breed ? 'error' : ''}`}
                    value={breed}
                    onChange={(e) => {
                      setBreed(e.target.value)
                      if (errors.breed) {
                        setErrors({ ...errors, breed: '' })
                      }
                    }}
                  >
                    <option value="">Select Breed Here....</option>
                    {petType === 'dog' ? (
                      <>
                        <option value="labrador">Labrador</option>
                        <option value="golden-retriever">Golden Retriever</option>
                        <option value="german-shepherd">German Shepherd</option>
                        <option value="bulldog">Bulldog</option>
                        <option value="poodle">Poodle</option>
                        <option value="beagle">Beagle</option>
                        <option value="rottweiler">Rottweiler</option>
                        <option value="yorkshire-terrier">Yorkshire Terrier</option>
                        <option value="other">Other</option>
                      </>
                    ) : (
                      <>
                        <option value="persian">Persian</option>
                        <option value="maine-coon">Maine Coon</option>
                        <option value="british-shorthair">British Shorthair</option>
                        <option value="ragdoll">Ragdoll</option>
                        <option value="bengal">Bengal</option>
                        <option value="siamese">Siamese</option>
                        <option value="american-shorthair">American Shorthair</option>
                        <option value="scottish-fold">Scottish Fold</option>
                        <option value="other">Other</option>
                      </>
                    )}
                  </select>
                  <svg className="pet-insurance-select-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 9L12 15L18 9" stroke="#666666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                {errors.breed && <p className="pet-insurance-error">{errors.breed}</p>}
              </div>

              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Your Name?</label>
                <input
                  type="text"
                  className={`pet-insurance-input ${errors.name ? 'error' : ''}`}
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value)
                    if (errors.name) {
                      setErrors({ ...errors, name: '' })
                    }
                  }}
                  placeholder="Your Full Name....."
                />
                {errors.name && <p className="pet-insurance-error">{errors.name}</p>}
              </div>

              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Your Email Id?</label>
                <input
                  type="email"
                  className={`pet-insurance-input ${errors.email ? 'error' : ''}`}
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    if (errors.email) {
                      setErrors({ ...errors, email: '' })
                    }
                  }}
                  placeholder="Your Valid Email Id ...."
                />
                {errors.email && <p className="pet-insurance-error">{errors.email}</p>}
              </div>

              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Your Contact Number</label>
                <input
                  type="tel"
                  className={`pet-insurance-input ${errors.contact ? 'error' : ''}`}
                  value={contact}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '')
                    if (value.length <= 10) {
                      setContact(value)
                      if (errors.contact) {
                        setErrors({ ...errors, contact: '' })
                      }
                    }
                  }}
                  placeholder="Your 10 Digit Mobile Number....."
                  maxLength="10"
                />
                {errors.contact && <p className="pet-insurance-error">{errors.contact}</p>}
              </div>

              <div className="pet-insurance-field">
                <label className="pet-insurance-label">Your Pet's Age In Years</label>
                <input
                  type="text"
                  className={`pet-insurance-input ${errors.petAge ? 'error' : ''}`}
                  value={petAge}
                  onChange={(e) => {
                    setPetAge(e.target.value)
                    if (errors.petAge) {
                      setErrors({ ...errors, petAge: '' })
                    }
                  }}
                  placeholder="Age Of Your Pet In Years....."
                />
                {errors.petAge && <p className="pet-insurance-error">{errors.petAge}</p>}
              </div>

              <button
                type="submit"
                className={`pet-insurance-submit-btn ${!isFormValid ? 'disabled' : ''}`}
                disabled={!isFormValid}
              >
                Get Pet Insurance Quotes
              </button>
            </form>
          </div>
        </div>

        <div className="bottom-navigation">
          <div className="nav-item" onClick={onBack}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.55 5.45 21 6 21H9M19 10L21 12M19 10V20C19 20.55 18.55 21 18 21H15M9 21C9.55 21 10 20.55 10 20V14C10 13.45 10.45 13 11 13H13C13.55 13 14 13.45 14 14V20C14 20.55 14.45 21 15 21M9 21H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Home</span>
          </div>
          <div className="nav-item" onClick={onShowBooking}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M9 12H15M9 16H15" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Booking</span>
          </div>
          <div className="nav-center-action" onClick={onShowPetPopup}>
            <div className="center-action-circle">
              <svg className="paw-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C10.9 2 10 2.9 10 4C10 5.1 10.9 6 12 6C13.1 6 14 5.1 14 4C14 2.9 13.1 2 12 2Z" fill="#F55810"/>
                <path d="M8 8C6.9 8 6 8.9 6 10C6 11.1 6.9 12 8 12C9.1 12 10 11.1 10 10C10 8.9 9.1 8 8 8Z" fill="#F55810"/>
                <path d="M16 8C14.9 8 14 8.9 14 10C14 11.1 14.9 12 16 12C17.1 12 18 11.1 18 10C18 8.9 17.1 8 16 8Z" fill="#F55810"/>
                <path d="M6 16C4.9 16 4 16.9 4 18C4 19.1 4.9 20 6 20C7.1 20 8 19.1 8 18C8 16.9 7.1 16 6 16Z" fill="#F55810"/>
                <path d="M18 16C16.9 16 16 16.9 16 18C16 19.1 16.9 20 18 20C19.1 20 20 19.1 20 18C20 16.9 19.1 16 18 16Z" fill="#F55810"/>
                <ellipse cx="12" cy="14" rx="3" ry="4" fill="#F55810"/>
              </svg>
              <svg className="plus-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 4V12M4 8H12" stroke="#F55810" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div className="nav-item" onClick={onShowMessages}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8" cy="10" r="1" fill="black"/>
              <circle cx="12" cy="10" r="1" fill="black"/>
              <circle cx="16" cy="10" r="1" fill="black"/>
            </svg>
            <span className="nav-text">Message</span>
          </div>
          <div className="nav-item" onClick={onShowProfile}>
            <svg className="nav-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="12" cy="7" r="4" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="nav-text">Me</span>
          </div>
        </div>

        {showPetPopup && (
          <div className="popup-overlay" onClick={() => setShowPetPopup(false)}>
            <div className="popup-content" onClick={(e) => e.stopPropagation()}>
              <h2 className="popup-title">Select Your Pet</h2>
              <div className="pet-selection-cards">
                <div 
                  className={`pet-card dog ${selectedPet === 'dog' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('dog')}
                >
                  <div className="pet-card-overlay-dog"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">DOG</span>
                  </div>
                </div>
                <div 
                  className={`pet-card cat ${selectedPet === 'cat' ? 'selected' : ''}`}
                  onClick={() => handlePetSelection('cat')}
                >
                  <div className="pet-card-overlay-cat"></div>
                  <div className="pet-card-content">
                    <span className="pet-card-text">CAT</span>
                  </div>
                </div>
              </div>
              <div className="popup-buttons">
                <button 
                  className="popup-button next-button"
                  onClick={() => handlePetSelection(selectedPet)}
                  disabled={!selectedPet}
                >
                  Next
                </button>
                <button 
                  className="popup-button cancel-button"
                  onClick={() => {
                    setShowPetPopup(false)
                    setSelectedPet(null)
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {showSideMenu && (
          <SideMenu 
            onClose={() => setShowSideMenu(false)}
            onLogout={onLogout}
          />
        )}
      </div>
    </div>
  )
}

export default PetInsurance

